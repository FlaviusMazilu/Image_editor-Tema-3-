//Copyright Mazilu Flavius-Romeo 314CAb 2021-2022
#ifndef __SELECT_
#define __SELECT_

void SELECT(int *x1, int *y1, int *x2, int *y2, int n, int m);

#endif
