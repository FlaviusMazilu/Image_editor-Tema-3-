//Copyright Mazilu Flavius-Romeo 314CAb 2021-2022
#ifndef __CROP__
#define __CROP__

pixel **CROP(pixel **a, info *p, int *x1, int *y1, int *x2, int *y2);

#endif
