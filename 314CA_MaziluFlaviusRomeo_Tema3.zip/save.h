//Copyright Mazilu Flavius-Romeo 314CAb 2021-2022
#ifndef __SAVE__
#define __SAVE__

void write_binary(pixel **a, int n, int m, int RGB, char nume_fisier[]);

void write_ascii(pixel **a, int n, int m, int RGB, char nume_fisier[]);

void SAVE(pixel **a, int n, int m, int RGB);

#endif
